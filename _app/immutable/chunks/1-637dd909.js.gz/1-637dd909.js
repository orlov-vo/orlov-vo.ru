import{default as t}from"../components/pages/_error.svelte-2086ef76.js";export{t as component};
