import{_ as r}from"./_page-cb487847.js";import{default as t}from"../components/pages/_...path_/_page.svelte-7dc27bcb.js";export{t as component,r as universal};
