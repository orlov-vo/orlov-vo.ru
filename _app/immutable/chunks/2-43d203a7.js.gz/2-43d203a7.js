import{default as t}from"../components/pages/_page.svelte-703c7843.js";export{t as component};
