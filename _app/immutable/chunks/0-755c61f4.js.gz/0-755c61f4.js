import{_ as r}from"./_layout-86c6cedc.js";import{default as t}from"../components/pages/_layout.svelte-dd8beb7a.js";export{t as component,r as shared};
