import{default as t}from"../components/pages/_error.svelte-ae6acc62.js";export{t as component};
