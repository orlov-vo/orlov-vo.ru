import{default as t}from"../components/pages/cv/_page.svelte-acbf2809.js";export{t as component};
