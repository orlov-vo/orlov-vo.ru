import{_ as r}from"./_page-211d1f2b.js";import{default as t}from"../components/pages/_...path_/_page.svelte-e5d9be95.js";export{t as component,r as shared};
