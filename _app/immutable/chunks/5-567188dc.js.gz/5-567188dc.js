import{default as t}from"../components/pages/posts/_page.svelte-c6cfed21.js";export{t as component};
