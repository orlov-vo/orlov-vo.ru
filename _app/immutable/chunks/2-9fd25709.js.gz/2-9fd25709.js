import{default as t}from"../components/pages/_page.svelte-99beb990.js";export{t as component};
