import{default as t}from"../components/pages/_error.svelte-e527bd28.js";export{t as component};
