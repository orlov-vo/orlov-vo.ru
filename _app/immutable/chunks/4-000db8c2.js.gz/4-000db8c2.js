import{default as t}from"../components/pages/cv/_page.svelte-553111bf.js";export{t as component};
