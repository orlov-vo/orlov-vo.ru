import{default as t}from"../components/pages/_error.svelte-5e8b2e3c.js";export{t as component};
