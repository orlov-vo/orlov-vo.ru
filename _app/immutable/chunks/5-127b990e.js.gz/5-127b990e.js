import{default as t}from"../components/pages/posts/_page.svelte-e6ea6c1f.js";export{t as component};
