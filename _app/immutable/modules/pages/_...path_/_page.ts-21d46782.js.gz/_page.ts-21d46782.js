import{l}from"../../../chunks/_page-211d1f2b.js";import"../../../chunks/posts-2a05f79d.js";export{l as load};
