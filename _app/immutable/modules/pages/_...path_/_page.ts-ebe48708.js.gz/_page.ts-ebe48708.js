import{l}from"../../../chunks/_page-cb487847.js";import"../../../chunks/posts-ede6274c.js";export{l as load};
