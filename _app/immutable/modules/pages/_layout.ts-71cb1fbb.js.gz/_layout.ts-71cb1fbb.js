import{p}from"../../chunks/_layout-86c6cedc.js";export{p as prerendered};
